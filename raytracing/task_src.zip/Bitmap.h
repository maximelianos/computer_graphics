#ifndef BITMAP_GUARDIAN_H
#define BITMAP_GUARDIAN_H

void SaveBMP(const char* fname, const unsigned int* pixels, int w, int h);

#endif 
